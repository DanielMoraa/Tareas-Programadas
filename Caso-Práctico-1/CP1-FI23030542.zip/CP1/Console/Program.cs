﻿namespace Console
{
    internal class Program
    {
        // ¿Qué es la secuencia Tribonacci? - https://www.geeksforgeeks.org/dsa/tribonacci-numbers/
        static long TribonacciRecursivo(int n)
        {
            if (n == 1 || n == 2)
            {
                // T(1) = 1
                // T(2) = 1
                return 1;
            }
            else if (n == 3)
            {
                // T(3) = 2
                return 2;
            }
            else
            {
                // T(n) = T(n - 1) + T(n - 2) + T(n - 3)
                return TribonacciRecursivo(n - 1) + TribonacciRecursivo(n - 2) + TribonacciRecursivo(n - 3);
            }
        }

        // Implementación iterativa de Tribonacci - https://claude.ai/ 
        static long TribonacciIterativo(int n)
        {
            // Primeros 3 valores de la secuencia Tribonacci
            if (n == 1 || n == 2) // T(1) y T(2)
            {
                return 1;
            }
            else if (n == 3) // T(3)
            {
                return 2;
            }

            long a = 1, b = 1, c = 2;
            long resultado = 0;

            for (int i = 4; i <= n; i++)
            {
                resultado = a + b + c;
                a = b;
                b = c;
                c = resultado;
            }

            return resultado;
        }
        static void Main(string[] args) // Le falta el [] a String args - https://learn.microsoft.com/es-es/dotnet/csharp/fundamentals/program-structure/main-command-line
        {
            System.Console.Write("Digite el valor de 'n': ");
            var valor = System.Console.ReadLine();
            var n = int.Parse(valor);

            if (n > 0 && n < 40)
            {
                var recursivo = TribonacciRecursivo(n);
                var iterativo = TribonacciIterativo(n);
                System.Console.WriteLine($"Tribonacci Recursivo: {recursivo}");
                System.Console.WriteLine($"Tribonacci Iterativo: {iterativo}");
            }
            else
            {
                System.Console.WriteLine("Error: El número debe estar entre 1 y 39 (inclusive).");
            }
        }
    }
}
