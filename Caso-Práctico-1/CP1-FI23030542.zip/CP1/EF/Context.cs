﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace EF
{
    // DBContext no puede ser private, ya que EF6 no puede acceder a ella si está en Private https://learn.microsoft.com/en-us/ef/core/dbcontext-configuration/
    internal class Context : DbContext
    {
        public Context() : base("DefaultConnection")
        {
            // Crear la base de datos si no existe - https://claude.ai/
            Database.SetInitializer(new CreateDatabaseIfNotExists<Context>());
        }

        public DbSet<Lotto> Lottos { get; set; }
        public DbSet<Numero> Numeros { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Configurar la relación uno a muchos entre Lotto y Numero - https://claude.ai/
            modelBuilder.Entity<Lotto>()
                .HasMany(l => l.Numeros)
                .WithRequired(n => n.Lotto)
                .HasForeignKey(n => n.LottoId);

            base.OnModelCreating(modelBuilder);
        }
    }

    [Table("Lotto")] //Para que evitemos pluralización de nombres de tablas en EF6
    public class Lotto
    {
        public int LottoId { get; set; }
        public DateTime FechaHora { get; set; }

        public virtual List<Numero> Numeros { get; set; }
    }

    [Table("Numero")]
    public class Numero
    {
        public int NumeroId { get; set; }
        public int Orden { get; set; }
        public int Num { get; set; }

        public int LottoId { get; set; }
        public virtual Lotto Lotto { get; set; }
    }
}

