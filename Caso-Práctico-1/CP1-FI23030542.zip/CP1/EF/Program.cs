﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var db = new Context())
            {
                Console.Write("Generando nuevo juego de Lotto con cinco Números... ");
                var lotto = new Lotto { FechaHora = DateTime.Now, Numeros = new List<Numero>() };
                var numeros = new HashSet<int>();
                var aleatorio = new Random();
                var orden = 1; // Se empieza en 1 para el orden de los números 

                // Se cambió de un for a un while para asegurar que se generen los cinco números - https://claude.ai/
                while (orden <= 5) 
                {
                    var num = aleatorio.Next(41); // Numeros de 0 a 40
                    if (!numeros.Contains(num)) //Validacion para que NO se repitan números
                    {
                        numeros.Add(num);
                        lotto.Numeros.Add(new Numero { Orden = orden, Num = num });
                        orden++;
                    }
                }

                db.Lottos.Add(lotto);
                Console.WriteLine("Listo\n");

                Console.Write("Guardando cambios en la base de datos... ");
                db.SaveChanges(); // FIX: Agregar SaveChanges para guardar en la base de datos - https://claude.ai/
                Console.WriteLine("Listo\n");

                Console.WriteLine("Imprimiendo los juegos de Lotto y sus Números:\n");

                // UPDATE: Imprimir todos los valores guardados en las tablas - https://claude.ai/
                var todosLosLottos = db.Lottos.Include("Numeros").ToList();

                foreach (var lottoItem in todosLosLottos)
                {
                    Console.WriteLine($"Lotto ID: {lottoItem.LottoId}, Fecha: {lottoItem.FechaHora:yyyy-MM-dd HH:mm:ss}");

                    var numerosOrdenados = lottoItem.Numeros.OrderBy(n => n.Orden).ToList();
                    foreach (var numero in numerosOrdenados)
                    {
                        Console.WriteLine($"  - Orden: {numero.Orden}, Número: {numero.Num}");
                    }
                    Console.WriteLine();
                }

                Console.WriteLine("Presione cualquier tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}