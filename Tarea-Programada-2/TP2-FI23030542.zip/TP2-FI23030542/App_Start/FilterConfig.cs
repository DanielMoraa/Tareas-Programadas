﻿using System.Web;
using System.Web.Mvc;

namespace TP2_FI23030542
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
