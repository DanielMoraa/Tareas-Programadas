﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TP2_FI23030542.Models;

namespace TP2_FI23030542.Controllers
{
    public class TriangleController : Controller
    {
        public ActionResult Index()
        {
            return View(new TriangleModel());
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(TriangleModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            if (!model.EsTrianguloValido())
            {
                ModelState.AddModelError("", "Los valores ingresados no forman un triángulo válido. La suma de dos lados debe ser mayor que el tercer lado.");
                return View(model);
            }

            model.CalcularPropiedades();

            return View(model);
        }
    }
}