﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TP2_FI23030542.Models
{
    public class TriangleModel
    {
        [Required(ErrorMessage = "El lado a es requerido")]
        [Range(0.01, double.MaxValue, ErrorMessage = "El lado a debe ser mayor que 0")]
        [Display(Name = "Lado a")]
        public double A { get; set; }

        [Required(ErrorMessage = "El lado b es requerido")]
        [Range(0.01, double.MaxValue, ErrorMessage = "El lado b debe ser mayor que 0")]
        [Display(Name = "Lado b")]
        public double B { get; set; }

        [Required(ErrorMessage = "El lado c es requerido")]
        [Range(0.01, double.MaxValue, ErrorMessage = "El lado c debe ser mayor que 0")]
        [Display(Name = "Lado c")]
        public double C { get; set; }

        public double Perimetro { get; set; }
        public double SemiPerimetro { get; set; }
        public double Area { get; set; }
        public string TipoTriangulo { get; set; }
        public double AnguloAlfa { get; set; }
        public double AnguloBeta { get; set; }
        public double AnguloGamma { get; set; }

        public bool EsTrianguloValido()
        {
            return (A + B > C) && (A + C > B) && (B + C > A);
        }

        public void CalcularPropiedades()
        {
            if (!EsTrianguloValido()) return;

            Perimetro = A + B + C;
            SemiPerimetro = Perimetro / 2;

            Area = Math.Sqrt(SemiPerimetro * (SemiPerimetro - A) * (SemiPerimetro - B) * (SemiPerimetro - C));

            if (A == B && B == C)
                TipoTriangulo = "Equilátero";
            else if (A == B || B == C || A == C)
                TipoTriangulo = "Isósceles";
            else
                TipoTriangulo = "Escaleno";

            AnguloAlfa = Math.Acos((B * B + C * C - A * A) / (2 * B * C)) * (180 / Math.PI);
            AnguloBeta = Math.Acos((A * A + C * C - B * B) / (2 * A * C)) * (180 / Math.PI);
            AnguloGamma = Math.Acos((A * A + B * B - C * C) / (2 * A * B)) * (180 / Math.PI);
        }
    }
}
