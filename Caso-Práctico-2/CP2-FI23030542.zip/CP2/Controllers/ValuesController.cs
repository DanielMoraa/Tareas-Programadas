﻿using System;
using System.Collections.Generic;
using System.Web.Http;

namespace CP2.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        // 8. Web API
        public IList<KeyValuePair<string, string>> Get()
        {
            return new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("Local", DateTime.Now.ToString()),
                new KeyValuePair<string, string>("Utc", DateTime.UtcNow.ToString()) // 8.Se utiliza DateTime.UtcNow para obtener la hora UTC actual. -- https://learn.microsoft.com/es-es/dotnet/api/system.datetime.utcnow?view=net-9.0
            };
        }

        // GET api/values/5
        public IList<int> Get(int number)
        {
            var list = new List<int>();
            var random = new Random(); 

            for (int i = 0; i < number; i++) //8. Ciclo para llenar la lista con números aleatorios.
            {
                list.Add(random.Next());
            }

            return list;
        }
    }
}
