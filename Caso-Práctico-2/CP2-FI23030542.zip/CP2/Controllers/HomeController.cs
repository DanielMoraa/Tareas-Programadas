﻿using System.Collections.Generic;
using System.Net;
using System.Web.Mvc;
namespace CP2.Controllers
{
    [Attributes.Log] //3. Filters: Uso de LogAttribute para que trabaje a nivel de TODOS los Actions.
    [HandleError(View = "Error")] //4. Errors: Redirije a la vista Error.cshtml al momento que haya una excepción a nivel GLOBAL del controlador.
    public class HomeController : Controller
    {
        private readonly IDictionary<int, bool> items = new Dictionary<int, bool>() // 9. Dictionary: Se verifica que todas las tareas estén hechas!
        {
            { 1, true },
            { 2, true },
            { 3, true },
            { 4, true },
            { 5, true },
            { 6, true },
            { 7, true },
            { 8, true },
            { 9, true },
        };

        public ActionResult Index() // 5. Data: Modificar los Actions Index y Redirect
        {
            ViewBag.Title = TempData["Title"] as string ?? "Home"; //5. Uso de TempData para pasar información entre acciones. - https://stackoverflow.com/questions/12422930/using-tempdata-in-asp-net-mvc-best-practice
            return View(items);
        }

        public ActionResult Redirect()
        {
            TempData["Title"] = "Redirect"; //5. Recibe el valor de TempData["Title"] en la vista Index.cshtml.
            return RedirectToAction("Index"); 
        }

        public ActionResult Ajax() //6. View: Se modifica el Action Ajax para que retorne una vista simple.
        {
            ViewBag.Title = "Ajax"; //6. Se define el título de la vista a "Ajax" por medio de VieBag.
            return View(); //6. Se hace return del View();
        }

        [Attributes.Auth]// 3. Filters: Se aplica el ActionFilter AuthAttribute SOLO a este Action, se encargará de que al darle click tire el Exception.
        public ActionResult Unauth() 
        {
            ViewBag.Title = "Unauth";
            return new HttpStatusCodeResult(HttpStatusCode.Unauthorized);
        }
    }
}