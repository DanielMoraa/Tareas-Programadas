﻿using System.Web.Mvc;
using System.Web.Mvc.Filters;

namespace CP2.Interfaces
{
    public interface IAuth : IAuthenticationFilter, IAuthorizationFilter
    {
    }
}
