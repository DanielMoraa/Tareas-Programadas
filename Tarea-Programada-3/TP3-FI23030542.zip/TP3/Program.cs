﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace TP3
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Producto> productosTemporales = new List<Producto>();

            bool continuar = true;

            while (continuar)
            {

                Console.Write("Escriba el nombre del producto. R/ ");
                string nombreProducto = Console.ReadLine();

                Console.Write("Escriba la cantidad de números aleatorios a generar. R/ ");
                int cantidadNumeros;
                while (!int.TryParse(Console.ReadLine(), out cantidadNumeros) || cantidadNumeros <= 0)
                {
                    Console.Write("Por favor ingrese un número válido mayor que 0. R/ ");
                }


                bool puedenRepetirse = true;

                if (cantidadNumeros <= 100)
                {
                    Console.Write("¿Los números se pueden repetir? (s/n). R/ ");
                    string respuestaRepetir;

                    do
                    {
                        respuestaRepetir = Console.ReadLine();
                        if (respuestaRepetir.ToLower() != "s" && respuestaRepetir.ToLower() != "n")
                        {
                            Console.Write("Por favor ingrese 's' o 'n'. R/ ");
                        }
                    } while (respuestaRepetir.ToLower() != "s" && respuestaRepetir.ToLower() != "n");

                    puedenRepetirse = respuestaRepetir.ToLower() == "s";
                }


                Producto producto = new Producto
                {
                    Nombre = nombreProducto,
                    FechaHora = DateTime.Now,
                    Numeros = new List<Numero>()
                };


                Random random = new Random();

                List<int> numerosGenerados = new List<int>();


                for (int i = 1; i <= cantidadNumeros; i++)
                {
                    int numeroAleatorio;

                    if (puedenRepetirse)
                    {
                        numeroAleatorio = random.Next(0, 100);
                    }
                    else
                    {
                        do
                        {
                            numeroAleatorio = random.Next(0, 100);
                        } while (numerosGenerados.Contains(numeroAleatorio));
                    }

                    numerosGenerados.Add(numeroAleatorio);


                    Numero numero = new Numero
                    {
                        Orden = i,
                        Num = numeroAleatorio,
                        Producto = producto
                    };

                    producto.Numeros.Add(numero);
                }

                productosTemporales.Add(producto);


                Console.WriteLine("Guardando cambios...");
                Console.WriteLine("... cambios Guardados");


                Console.Write("¿Desea continuar agregando Productos? (s/n) ");
                string respuestaContinuar;
                do
                {
                    respuestaContinuar = Console.ReadLine();
                    if (respuestaContinuar.ToLower() != "s" && respuestaContinuar.ToLower() != "n")
                    {
                        Console.Write("Por favor ingrese 's' o 'n'. R/ ");
                    }
                } while (respuestaContinuar.ToLower() != "s" && respuestaContinuar.ToLower() != "n");

                continuar = respuestaContinuar.ToLower() == "s";
            }


            using (var db = new TP3Context())
            {
                foreach (var producto in productosTemporales)
                {
                    db.Productos.Add(producto);
                }
                db.SaveChanges();

                Console.WriteLine();
                var productosDB = db.Productos
                    .Include(p => p.Numeros)
                    .OrderBy(p => p.FechaHora)
                    .ToList();

                foreach (var producto in productosDB)
                {
                    Console.WriteLine($"{producto.ProductoId} → {producto.Nombre} - {producto.FechaHora:dd/MM/yyyy HH:mm}");

                    var numerosOrdenados = producto.Numeros.OrderBy(n => n.Orden).ToList();
                    foreach (var numero in numerosOrdenados)
                    {
                        Console.WriteLine($"    {numero.NumeroId} →[{numero.Orden}] {numero.Num}");
                    }
                    Console.WriteLine();
                }
            }

            Console.WriteLine("Programa finalizado. Presione la tecla enter para terminar.");
            Console.ReadKey();
        }
    }
    [Table("Producto")]
    public class Producto
    {
        public int ProductoId { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaHora { get; set; }

        public virtual List<Numero> Numeros { get; set; }
    }

    [Table("Numero")]
    public class Numero
    {
        public int NumeroId { get; set; }
        public int Orden { get; set; }
        public int Num { get; set; }
        public int ProductoId { get; set; }

        public virtual Producto Producto { get; set; }
    }
}