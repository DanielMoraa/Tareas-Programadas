﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    public class TP3Context : DbContext
    {
        public TP3Context() : base("TP3")
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<TP3Context>());
        }

        public DbSet<Producto> Productos { get; set; }
        public DbSet<Numero> Numeros { get; set; }
    }
}
